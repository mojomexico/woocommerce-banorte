<?php
/*
Plugin Name: Banorte conexion PW2-3D para WC
Plugin URI: https://mojomexico.company/portal/producto-categoria/woocommerce-wordpress/ 
Description: Pasarela Banco Banorte, aceptar tarjetas de credito y débito en tu tienda WooCommerce, preguntas, dudas y otras marcas de banco <a href="https://mojomexico.com.mx" target="_blank">dar clic aqui</a> para conocer nuestro catalogo.
Version: 0.1 3D-PAYWORK2 DEMO, Puedes orderar tu version final en nuestra tienda web.
Author: SR-Mojomexico 
Author URI: http://mojomexico.com.mx
Developer: SergioRomo by Mojomexico
Developer URI: https://mojomexico.com.mx/
Text Domain: Mojomexico Banorte

*/

if ( ! defined( 'ABSPATH' ) )
	exit;

add_action('plugins_loaded', 'woocommerce_banorte_init', 0);

function woocommerce_banorte_init() {

	if ( ! class_exists( 'WC_Payment_Gateway' ) ) { return; }
        
        require_once(WP_PLUGIN_DIR . "/" . plugin_basename( dirname(__FILE__)) . '/woo_banorte.php');
        
	}
